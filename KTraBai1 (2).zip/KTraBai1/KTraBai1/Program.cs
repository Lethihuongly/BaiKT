using KTraBai1.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = null; // Tr? v? JSON v?i t�n thu?c t�nh nguy�n b?n
    });

// K?t n?i CSDL qua chu?i k?t n?i t? appsettings.json
builder.Services.AddDbContext<GoodsDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// H? tr? Swagger UI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// C?u h�nh CORS (cho ph�p t?t c? ngu?n g?c - t�y ch?nh theo nhu c?u)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// H? tr? HTTPS (b?t ho?c t?t t�y y�u c?u, m?c ??nh b?t trong m�i tr??ng ph�t tri?n)
app.UseHttpsRedirection();

// S? d?ng CORS
app.UseCors("AllowAll");

app.UseAuthorization();

app.MapControllers();

app.Run();