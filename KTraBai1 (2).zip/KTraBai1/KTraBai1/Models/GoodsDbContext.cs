﻿using Microsoft.EntityFrameworkCore;
namespace KTraBai1.Models
{
    public class GoodsDbContext : DbContext
    {
        public GoodsDbContext(DbContextOptions<GoodsDbContext> options) : base(options)
        {
        }

        // Constructor mặc định cho design-time (Migration)
        public GoodsDbContext()
        {
        }

        public DbSet<HangHoa> Goods { get; set; }

        // Cấu hình chuỗi kết nối trong OnConfiguring (dùng cho Migration)
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Chuỗi kết nối mặc định nếu không được cấu hình qua DI
                optionsBuilder.UseSqlServer("Server=ADMIN\\SQLEXPRESS;Database=GoodDB;Trusted_Connection=True;TrustServerCertificate=True;");
            }
        }
    }
}
